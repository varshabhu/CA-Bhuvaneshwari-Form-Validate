import React from 'react';
import {useState} from 'react';

const DemoSta=()=>{
    const [movie,setMovie]=useState({
        moviename:"lovetoday",
        rating:9.6,
        ticketprice:700

    })
    const updateMovie=()=>{
        setMovie({
            moviename:"avatar",
            rating:"10",
            ticketprice:500,

        })
    }

    return(
        <div>
            <h2>movie Deatils:{movie.moviename} Rating is: {movie.rating} Cost of ticket is:{movie.ticketprice}</h2>
            <button onClick={updateMovie}>click me</button>
        </div>
    
    )

}

export default DemoSta;