const page1=() =>{
    return (
        <div>
        <h1>This is a Page 1</h1>
        <button>Go to page2</button>
        </div>

    )
}