const page1=() =>{
    return (
        <div>
        <h1>This is a Page 2</h1>
        <button>Go to page1</button>
        </div>

    )
}