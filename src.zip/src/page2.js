import { Link } from "react-router-dom";

const Page2 = () =>{
    return (
        <div>
        <h1>This is a Page 2</h1>
        <button><Link to='/page1'>Go to page1</Link></button>
        </div>

    )
}

export default Page2