import React from 'react';
import {useState} from 'react';

const DemoSta=()=>{
    const [count,setCount] = useState(0)

    const updateCount=()=>{
        setCount(count+50)
    }

    return(
        <>
        <h2>my initial count is {count}</h2>
        <button onClick={updateCount}>click me</button>
        </>
    )

}

export default DemoSta;