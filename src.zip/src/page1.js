import { Link } from "react-router-dom";

const Page1=() =>{
    return (
        <div>
        <h1>This is a Page 1</h1>
        <button><Link to='/page2'>Go to page2</Link></button>
        </div>

    )
}
export default Page1