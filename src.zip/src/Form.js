import React from 'react';  
class Form extends React.Component {   
  constructor(props) {
      super(props);  
      this.updateSubmit = this.updateSubmit.bind(this); 
      this.input = React.createRef();  
  }  
  updateSubmit(event) {  
      alert('You have entered the Username and Company name successfully.');  
      event.preventDefault();  
  }  
  render() {  
    return (  
      <center>
      <form onSubmit={this.updateSubmit}>  
        <h1>Uncontrolled Form Example</h1><br></br>  
        <label>Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" ref={this.input} />  
        </label>  <br></br><br></br>
        <label>  
            CompanyName:  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" ref={this.input} />  
        </label>  <br></br><br></br>
        <input type="submit" value="Submit" />  
      </form>  
      </center>
    );  
  }  
}  
export default Form;