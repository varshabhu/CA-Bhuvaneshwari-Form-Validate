import React from 'react';  
class Form extends React.Component {  //function 
  constructor(props) {  //initial create
      super(props);  
      this.updateSubmit = this.updateSubmit.bind(this); // 
      this.input = React.createRef();  
  }  
  updateSubmit(event) {  
      alert('you have logged in');  
      event.preventDefault();  
  }  
  render() {  
    return (  
      <center>
      <form onSubmit={this.updateSubmit}> 
      <br></br>
      <fieldset>
        <h1>THE NEWS CLUB!</h1><br></br>  
        <label>Email Id:  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" required ref={this.input} />  
        </label>  <br></br><br></br>
        <label>  
            Password:  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text"required ref={this.input} />  
        </label>  <br></br><br></br>


        <input type="Submit" value="Log in" />  
        <h6> Don't have an account? </h6>
        <input type="button"value="Create a new account"></input> 
        </fieldset>


      </form>  
      </center>
    
    );  
  }  
}  
export default Form;