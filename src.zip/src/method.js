import React from 'react';
import {useState} from 'react';

const DemoSta=()=>{
    const [name,setName] = useState("bhu")

    return(
        <>
        <h2>my initial count is {name}</h2>
        <button onClick={()=>setName("Bhuvaneshwari")}>click me</button>
        </>
    )

}

export default DemoSta;